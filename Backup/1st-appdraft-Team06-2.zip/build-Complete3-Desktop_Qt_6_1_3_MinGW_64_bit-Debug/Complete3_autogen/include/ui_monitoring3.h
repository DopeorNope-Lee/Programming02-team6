/********************************************************************************
** Form generated from reading UI file 'monitoring3.ui'
**
** Created by: Qt User Interface Compiler version 6.1.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MONITORING3_H
#define UI_MONITORING3_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Monitoring3
{
public:
    QFrame *line;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *year_label;
    QSpinBox *YearspinBox;
    QLabel *month_label;
    QComboBox *monthspinBox;
    QLabel *category;
    QPushButton *cancleButton;
    QPushButton *pushButton;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *plan_label;
    QLabel *expense_label;
    QHBoxLayout *horizontalLayout_3;
    QTableWidget *Plantable;
    QTableWidget *Expensetable;

    void setupUi(QDialog *Monitoring3)
    {
        if (Monitoring3->objectName().isEmpty())
            Monitoring3->setObjectName(QString::fromUtf8("Monitoring3"));
        Monitoring3->resize(545, 396);
        line = new QFrame(Monitoring3);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(260, 80, 20, 281));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        layoutWidget = new QWidget(Monitoring3);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 40, 261, 26));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        year_label = new QLabel(layoutWidget);
        year_label->setObjectName(QString::fromUtf8("year_label"));

        horizontalLayout->addWidget(year_label);

        YearspinBox = new QSpinBox(layoutWidget);
        YearspinBox->setObjectName(QString::fromUtf8("YearspinBox"));
        YearspinBox->setMinimum(2000);
        YearspinBox->setMaximum(2030);
        YearspinBox->setValue(2021);

        horizontalLayout->addWidget(YearspinBox);

        month_label = new QLabel(layoutWidget);
        month_label->setObjectName(QString::fromUtf8("month_label"));

        horizontalLayout->addWidget(month_label);

        monthspinBox = new QComboBox(layoutWidget);
        monthspinBox->addItem(QString());
        monthspinBox->addItem(QString());
        monthspinBox->addItem(QString());
        monthspinBox->addItem(QString());
        monthspinBox->addItem(QString());
        monthspinBox->addItem(QString());
        monthspinBox->addItem(QString());
        monthspinBox->addItem(QString());
        monthspinBox->addItem(QString());
        monthspinBox->addItem(QString());
        monthspinBox->addItem(QString());
        monthspinBox->addItem(QString());
        monthspinBox->setObjectName(QString::fromUtf8("monthspinBox"));

        horizontalLayout->addWidget(monthspinBox);

        category = new QLabel(Monitoring3);
        category->setObjectName(QString::fromUtf8("category"));
        category->setGeometry(QRect(10, 10, 91, 16));
        QFont font;
        font.setFamilies({QString::fromUtf8("Agency FB")});
        font.setPointSize(11);
        font.setBold(true);
        category->setFont(font);
        cancleButton = new QPushButton(Monitoring3);
        cancleButton->setObjectName(QString::fromUtf8("cancleButton"));
        cancleButton->setGeometry(QRect(450, 360, 80, 20));
        pushButton = new QPushButton(Monitoring3);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(280, 40, 86, 24));
        layoutWidget1 = new QWidget(Monitoring3);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 80, 521, 271));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        plan_label = new QLabel(layoutWidget1);
        plan_label->setObjectName(QString::fromUtf8("plan_label"));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("\352\265\264\353\246\274")});
        font1.setPointSize(8);
        plan_label->setFont(font1);

        horizontalLayout_2->addWidget(plan_label);

        expense_label = new QLabel(layoutWidget1);
        expense_label->setObjectName(QString::fromUtf8("expense_label"));
        expense_label->setFont(font1);

        horizontalLayout_2->addWidget(expense_label);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        Plantable = new QTableWidget(layoutWidget1);
        if (Plantable->columnCount() < 2)
            Plantable->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        Plantable->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        Plantable->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        Plantable->setObjectName(QString::fromUtf8("Plantable"));

        horizontalLayout_3->addWidget(Plantable);

        Expensetable = new QTableWidget(layoutWidget1);
        if (Expensetable->columnCount() < 2)
            Expensetable->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        Expensetable->setHorizontalHeaderItem(0, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        Expensetable->setHorizontalHeaderItem(1, __qtablewidgetitem3);
        Expensetable->setObjectName(QString::fromUtf8("Expensetable"));

        horizontalLayout_3->addWidget(Expensetable);


        verticalLayout->addLayout(horizontalLayout_3);


        retranslateUi(Monitoring3);

        QMetaObject::connectSlotsByName(Monitoring3);
    } // setupUi

    void retranslateUi(QDialog *Monitoring3)
    {
        Monitoring3->setWindowTitle(QCoreApplication::translate("Monitoring3", "Dialog", nullptr));
        year_label->setText(QCoreApplication::translate("Monitoring3", "Year", nullptr));
        month_label->setText(QCoreApplication::translate("Monitoring3", "Month", nullptr));
        monthspinBox->setItemText(0, QCoreApplication::translate("Monitoring3", "Jan", nullptr));
        monthspinBox->setItemText(1, QCoreApplication::translate("Monitoring3", "Feb", nullptr));
        monthspinBox->setItemText(2, QCoreApplication::translate("Monitoring3", "Mar", nullptr));
        monthspinBox->setItemText(3, QCoreApplication::translate("Monitoring3", "Apr", nullptr));
        monthspinBox->setItemText(4, QCoreApplication::translate("Monitoring3", "May", nullptr));
        monthspinBox->setItemText(5, QCoreApplication::translate("Monitoring3", "Jun", nullptr));
        monthspinBox->setItemText(6, QCoreApplication::translate("Monitoring3", "July", nullptr));
        monthspinBox->setItemText(7, QCoreApplication::translate("Monitoring3", "Aug", nullptr));
        monthspinBox->setItemText(8, QCoreApplication::translate("Monitoring3", "Sep", nullptr));
        monthspinBox->setItemText(9, QCoreApplication::translate("Monitoring3", "Oct", nullptr));
        monthspinBox->setItemText(10, QCoreApplication::translate("Monitoring3", "Nov", nullptr));
        monthspinBox->setItemText(11, QCoreApplication::translate("Monitoring3", "Dec", nullptr));

        monthspinBox->setCurrentText(QCoreApplication::translate("Monitoring3", "Nov", nullptr));
        monthspinBox->setPlaceholderText(QString());
        category->setText(QCoreApplication::translate("Monitoring3", "By category", nullptr));
        cancleButton->setText(QCoreApplication::translate("Monitoring3", "Close", nullptr));
        pushButton->setText(QCoreApplication::translate("Monitoring3", "Import", nullptr));
        plan_label->setText(QCoreApplication::translate("Monitoring3", "<Plan>", nullptr));
        expense_label->setText(QCoreApplication::translate("Monitoring3", "<Expense>", nullptr));
        QTableWidgetItem *___qtablewidgetitem = Plantable->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("Monitoring3", "Category", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = Plantable->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("Monitoring3", "Amount", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = Expensetable->horizontalHeaderItem(0);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("Monitoring3", "Category", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = Expensetable->horizontalHeaderItem(1);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("Monitoring3", "Amount", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Monitoring3: public Ui_Monitoring3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MONITORING3_H
