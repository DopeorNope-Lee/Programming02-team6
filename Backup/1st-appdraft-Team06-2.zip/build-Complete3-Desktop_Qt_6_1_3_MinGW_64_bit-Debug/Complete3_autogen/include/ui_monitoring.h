/********************************************************************************
** Form generated from reading UI file 'monitoring.ui'
**
** Created by: Qt User Interface Compiler version 6.1.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MONITORING_H
#define UI_MONITORING_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Monitoring
{
public:
    QLabel *mornitoring;
    QPushButton *pushButton;
    QPushButton *pushButton_4;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;

    void setupUi(QDialog *Monitoring)
    {
        if (Monitoring->objectName().isEmpty())
            Monitoring->setObjectName(QString::fromUtf8("Monitoring"));
        Monitoring->resize(573, 365);
        mornitoring = new QLabel(Monitoring);
        mornitoring->setObjectName(QString::fromUtf8("mornitoring"));
        mornitoring->setGeometry(QRect(10, 20, 531, 41));
        QFont font;
        font.setFamilies({QString::fromUtf8("Agency FB")});
        font.setPointSize(12);
        font.setBold(true);
        mornitoring->setFont(font);
        mornitoring->setFrameShape(QFrame::WinPanel);
        pushButton = new QPushButton(Monitoring);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(40, 170, 111, 20));
        pushButton_4 = new QPushButton(Monitoring);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(450, 320, 80, 20));
        pushButton_2 = new QPushButton(Monitoring);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(230, 170, 101, 20));
        pushButton_3 = new QPushButton(Monitoring);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(400, 170, 101, 20));

        retranslateUi(Monitoring);

        QMetaObject::connectSlotsByName(Monitoring);
    } // setupUi

    void retranslateUi(QDialog *Monitoring)
    {
        Monitoring->setWindowTitle(QCoreApplication::translate("Monitoring", "Dialog", nullptr));
        mornitoring->setText(QCoreApplication::translate("Monitoring", "Monitoring", nullptr));
        pushButton->setText(QCoreApplication::translate("Monitoring", "Total expense", nullptr));
        pushButton_4->setText(QCoreApplication::translate("Monitoring", "Close", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Monitoring", "By Year,Month", nullptr));
        pushButton_3->setText(QCoreApplication::translate("Monitoring", "By Category", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Monitoring: public Ui_Monitoring {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MONITORING_H
